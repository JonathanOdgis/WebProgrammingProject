define([
	"./deletedIds"
], function( deletedIds ) {
	return deletedIds.indexOf;
});
